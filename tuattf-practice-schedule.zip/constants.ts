
export const SPREADSHEET_ID = '1utxuwDZsrLZ5cTq8uIPRdOmMvlE9O1IbE1ymsIey3Uo';
export const MONTHS = Array.from({ length: 12 }, (_, i) => i + 1); // 1 to 12
export const DATA_YEAR = 2025; // Export DATA_YEAR
